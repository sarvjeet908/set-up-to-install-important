const nameInput = document.getElementById('name');
const marksInput = document.getElementById('marks');
const addBtn = document.getElementById('addBtn');
const fetchBtn = document.getElementById('fetchBtn');
const statusSpan = document.getElementById('status');
const tbody = document.querySelector('#studentsTable tbody');

function setStatus(msg, isError) {
  statusSpan.textContent = msg || '';
  statusSpan.style.color = isError ? 'red' : '#666';
}

async function fetchStudents() {
  setStatus('Loading...');
  fetchBtn.disabled = true;
  try {
    const res = await fetch('/students', { cache: 'no-store' });
    if (!res.ok) {
      const text = await res.text();
      throw new Error('Server error: ' + res.status + ' ' + text);
    }
    const data = await res.json();
    renderTable(data);
    setStatus('Loaded ' + data.length + ' students');
  } catch (err) {
    console.error('Fetch error', err);
    setStatus('Failed to fetch students: ' + (err.message || err), true);
    renderTable([]); // clear table to avoid inconsistent UI
  } finally {
    fetchBtn.disabled = false;
  }
}

function renderTable(rows) {
  tbody.innerHTML = '';
  if (!Array.isArray(rows) || rows.length === 0) {
    tbody.innerHTML = '<tr><td colspan="3">No records</td></tr>';
    return;
  }
  for (const r of rows) {
    const tr = document.createElement('tr');
    const idTd = document.createElement('td');
    idTd.textContent = r.id;
    const nameTd = document.createElement('td');
    nameTd.textContent = r.name;
    const marksTd = document.createElement('td');
    marksTd.textContent = r.marks;
    tr.appendChild(idTd);
    tr.appendChild(nameTd);
    tr.appendChild(marksTd);
    tbody.appendChild(tr);
  }
}

addBtn.addEventListener('click', async () => {
  const name = nameInput.value && nameInput.value.trim();
  const marks = marksInput.value && marksInput.value.trim();
  if (!name || !marks) {
    setStatus('Name and marks required', true);
    return;
  }
  addBtn.disabled = true;
  setStatus('Adding...');
  try {
    const res = await fetch('/students', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, marks: Number(marks) })
    });
    if (!res.ok) {
      const body = await res.json().catch(()=>null);
      throw new Error(body && body.error ? body.error : 'HTTP ' + res.status);
    }
    const body = await res.json();
    setStatus('Added id: ' + body.insertId);
    nameInput.value = '';
    marksInput.value = '';
    // refresh list
    await fetchStudents();
  } catch (err) {
    console.error('Add error', err);
    setStatus('Add failed: ' + (err.message || err), true);
  } finally {
    addBtn.disabled = false;
  }
});


// Allow manual refresh
fetchBtn.addEventListener('click', fetchStudents);

// initial load
fetchStudents();
