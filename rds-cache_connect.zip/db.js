const mysql = require('mysql2/promise');
require('dotenv').config();
const logger = require('./logger');

const pool = mysql.createPool({
  host: process.env.RDS_WRITER_HOST,
  user: process.env.RDS_USER,
  password: process.env.RDS_PASSWORD,
  database: process.env.RDS_DB,
  waitForConnections: true,
  connectionLimit: parseInt(process.env.DB_CONN_LIMIT || '10', 10),
  queueLimit: 0,
  connectTimeout: 10000,
  ...(process.env.RDS_USE_SSL === 'true' ? { ssl: { rejectUnauthorized: false } } : {})
});

logger.info('✅ RDS Writer Pool Initialized');
module.exports = pool;
