const pool = require('./db');
const logger = require('./logger');

function sleep(ms) {
  return new Promise(res => setTimeout(res, ms));
}

async function addStudent(name, marks) {
  const retries = 3;
  for (let attempt = 1; attempt <= retries; attempt++) {
    const conn = await pool.getConnection();
    try {
      logger.info(`📝 Writing to RDS Writer... (attempt ${attempt}) name=${name} marks=${marks}`);
      const [result] = await conn.execute(
        'INSERT INTO students (name, marks) VALUES (?, ?)',
        [name, marks]
      );
      logger.info(`✅ Successfully written to RDS (insertId: ${result.insertId})`);
      return result;
    } catch (err) {
      logger.error(`❌ Error writing to RDS: ${err && err.message ? err.message : String(err)}`);
      if (attempt === retries) throw err;
      logger.info(`Retrying after delay... (attempt ${attempt})`);
      await sleep(1000 * attempt);
    } finally {
      try { conn.release(); } catch(e) {}
    }
  }
}

module.exports = { addStudent };
