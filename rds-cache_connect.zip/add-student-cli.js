require('dotenv').config();
const { addStudent } = require('./rdsWriter');

(async () => {
  const [,, name, marks] = process.argv;
  if (!name || !marks) {
    console.log("Usage: node add-student-cli.js <name> <marks>");
    process.exit(1);
  }

  try {
    const res = await addStudent(name, parseInt(marks));
    console.log("✅ Inserted:", res.insertId);
  } catch (err) {
    console.error("❌ Failed:", err && err.message ? err.message : String(err));
    process.exit(2);
  }
})();
