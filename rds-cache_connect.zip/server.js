require('dotenv').config();
const path = require('path');
const express = require('express');
const bodyParser = require('body-parser');
const logger = require('./logger');
const redis = require('./valkey');
const readerPool = require('./dbReader');
const { addStudent } = require('./rdsWriter');

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static frontend
const publicDir = path.join(__dirname, 'public');
app.use(express.static(publicDir));

// Health check
app.get('/health', (req, res) => res.json({ ok: true, ts: Date.now() }));

// GET /students - reads from cache (Valkey) if available, otherwise from RDS reader pool
app.get('/students', async (req, res) => {
  try {
    // Try cache first (if redis configured). Redis operations are wrapped so failures won't break the endpoint.
    try {
      if (redis && typeof redis.get === 'function') {
        const cache = await redis.get('students:all');
        if (cache) {
          logger.info('📦 Serving students from Valkey cache');
          return res.json(JSON.parse(cache));
        }
      }
    } catch (cacheErr) {
      logger.error('⚠️ Valkey read failed: ' + (cacheErr && cacheErr.message ? cacheErr.message : String(cacheErr)));
      // continue to fetch from DB
    }

    // Fetch from reader pool (use pool.query directly)
    const [rows] = await readerPool.query('SELECT id, name, marks FROM students ORDER BY id DESC LIMIT 100');
    
    // Attempt to cache result (best-effort)
    try {
      if (redis && typeof redis.set === 'function') {
        await redis.set('students:all', JSON.stringify(rows), 'EX', 60);
      }
    } catch (cacheErr) {
      logger.error('⚠️ Valkey write failed: ' + (cacheErr && cacheErr.message ? cacheErr.message : String(cacheErr)));
    }

    logger.info('📘 Data fetched from RDS Reader and returned');
    return res.json(rows);
  } catch (err) {
    logger.error(`❌ Error fetching students: ${err && err.message ? err.message : String(err)}`);
    return res.status(500).json({ error: 'Failed to fetch students', details: (err && err.message ? err.message : String(err)) });
  }
});

// POST /students - write + invalidate cache
app.post('/students', async (req, res) => {
  try {
    const { name, marks } = req.body;
    if (!name || typeof marks === 'undefined' || marks === null) {
      return res.status(400).json({ error: 'name and marks are required' });
    }
    const result = await addStudent(String(name), Number(marks));
    // Invalidate cache (best-effort)
    try {
      if (redis && typeof redis.del === 'function') {
        await redis.del('students:all');
      }
    } catch (cacheErr) {
      logger.error('⚠️ Valkey invalidate failed: ' + (cacheErr && cacheErr.message ? cacheErr.message : String(cacheErr)));
    }
    return res.json({ insertId: result.insertId });
  } catch (err) {
    logger.error(`❌ Error adding student: ${err && err.message ? err.message : String(err)}`);
    return res.status(500).json({ error: 'Failed to add student', details: (err && err.message ? err.message : String(err)) });
  }
});

// fallback to index.html for SPA
app.get('*', (req, res) => {
  res.sendFile(path.join(publicDir, 'index.html'));
});

// Start server
const PORT = parseInt(process.env.PORT || '3000', 10);
app.listen(PORT, () => {
  logger.info(`🚀 Server running at http://localhost:${PORT}`);
});
