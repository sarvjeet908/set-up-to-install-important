# RDS + Valkey Demo (Backend + Simple UI)

This project bundles a backend (Express) and a simple frontend (static HTML+JS) served from the same server.

## Setup

1. Copy `.env.example` -> `.env` and fill values.
2. Install deps:
   ```
   npm install
   ```
3. Start server:
   ```
   nohup node server.js > app.log 2>&1 &
   tail -f app.log
   ```
4. Open browser to `http://<your-ec2-ip>:3000/`

