const mysql = require('mysql2/promise');
require('dotenv').config();
const logger = require('./logger');

const readerPool = mysql.createPool({
  host: process.env.RDS_READER_HOST,
  user: process.env.RDS_USER,
  password: process.env.RDS_PASSWORD,
  database: process.env.RDS_DB,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  connectTimeout: 10000,
  ...(process.env.RDS_USE_SSL === 'true' ? { ssl: { rejectUnauthorized: false } } : {})
});

logger.info('✅ RDS Reader Pool Initialized');
module.exports = readerPool;
