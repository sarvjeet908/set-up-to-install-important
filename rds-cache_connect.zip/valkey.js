const Redis = require('ioredis');
require('dotenv').config();
const logger = require('./logger');

const redis = new Redis({
  host: process.env.VALKEY_HOST,
  port: parseInt(process.env.VALKEY_PORT || '6379', 10),
  retryStrategy(times) {
    const delay = Math.min(times * 50, 2000);
    return delay;
  }
});

redis.on('connect', () => logger.info('✅ Connected to Valkey Cache'));
redis.on('error', (err) => logger.error('❌ Valkey Error: ' + (err && err.message ? err.message : String(err))));

module.exports = redis;
